#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

import pymysql
import cgi


conn=pymysql.connect("localhost","root","","supermarket")
cur=conn.cursor()
form=cgi.FieldStorage()
pid=form.getvalue("id")

print("""
   <!doctype html>
<html>
<head>
 <title>Automatic supermarket admin pannel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrap/styleTV.css">
  <script src="bootstrap/jquery/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script language="javascript" type="text/javascript" src="username.js"></script>
<link rel="icon" type="image/ico" href="images/tv_logo.png">
<script type="text/javascript">
	$(function()
	{
		$(this).bind('contextmenu',function()
		{
			return false;
		})
	})

</script>
<style>
html body {
  height: 100%;
   background: url(images/market2.jpeg) no-repeat center center fixed ; 
  background-size: cover;

}

#content_body {
    position:absolute;
	top:100px;
	bottom:30px;
	right:0;
	left:0;
	overflow:auto;
    z-index:inherit;
}
#header {position:fixed; top: 0; left:0; width: 100%;z-index:1;height:120px;background-color:blue;}
#footer { position:fixed; bottom: 0; left:0; width: 100%;background-color:transparent;z-index:1;color:black;font-family:"Comic Sans MS", cursive, sans-serif;text-align:center;}
/*#font_head
{
font-family:'Tangerine', serif;
font-size:40px;
font-weight:bold;
font-variant:small-caps;
text-align:center;
background: linear-gradient(90deg, #f0f, #00f, #f0f);
overflow: hidden;
background-repeat: no-repeat;
background-size: 80%;
animation: animate 3s linear infinite;

}*/
#font_head

{
font-family:'Tangerine', serif;
font-size:40px;
font-weight:bold;
font-variant:small-caps;
text-align:center;
overflow: hidden;
background: linear-gradient(#f00, #000);
background-repeat: no-repeat;
background-size: 100%;
letter-spacing: 3px;
/*animation: animate 3s linear infinite;*/
-webkit-background-clip: text;
-webkit-text-fill-color: rgba(255, 255, 255, 0);
text-align:center;

/*color:black;*/
}
#font_menu
{
font-family:"Comic Sans MS", cursive, sans-serif;
font-size:20px;
font-weight:bold;
font-variant:small-caps;
color:black;
}
#font_dashmenu
{
font-family:"Comic Sans MS", cursive, sans-serif;
font-size:15px;
font-weight:bold;
font-variant:small-caps;
color:black;
}
#font_dash
{
font-family:"Gill Sans", sans-serif;
font-size:18px;
font-weight:bold;
font-variant:small-caps;
color:black;
}


#wrapper {
    padding-left: 0;    
}

#page-wrapper {
    width: 100%;        
     padding: 0;
    background-color: #fff;
}
#dash_content
{
left:600px;
}
@media(min-width:768px) {
    #wrapper {
        padding-left: 225px;
    }

    #page-wrapper {
        padding: 22px 10px;
    }
}

/* Top Navigation */

.top-nav {
    padding: 0 15px;
}

.top-nav>li {
    display: inline-block;
    float: left;
}

.top-nav>li>a {
    padding-top: 20px;
    padding-bottom: 20px;
    line-height: 20px;
    color: #fff;
}

.top-nav>li>a:hover,
.top-nav>li>a:focus,
.top-nav>.open>a,
.top-nav>.open>a:hover,
.top-nav>.open>a:focus {
    color: #fff;
    background-color: #1a242f;
}

.top-nav>.open>.dropdown-menu {
    float: left;
    position: absolute;
    margin-top: 0;
    /*border: 1px solid rgba(0,0,0,.15);*/
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    background-color: #fff;
    -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    box-shadow: 0 6px 12px rgba(0,0,0,.175);
}

.top-nav>.open>.dropdown-menu>li>a {
    white-space: normal;
}


/* Side Navigation */

@media(min-width:768px) {
    .side-nav {
        position: fixed;
        top: 120px;
        left: 225px;
        width: 260px;
        margin-left: -225px;
        border: none;
        border-radius: 0;
        border-top: 1px rgba(0,0,0,.5) solid;
        overflow-y: auto;
        background-color: transparent;
		background-color:blue;
        /*background-color: #5A6B7D;*/
        bottom: 30px;
        overflow-x: hidden;
        padding-bottom: 40px;
    }

    .side-nav>li>a {
        width: 260px;
        border-bottom: 1px rgba(0,0,0,.3) solid;
    }

    .side-nav li a:hover,
    .side-nav li a:focus {
        outline: none;
        background-color: #77f !important;
    }
}

.side-nav>li>ul {
    padding: 0;
    border-bottom: 1px rgba(0,0,0,.3) solid;
}

.side-nav>li>ul>li>a {
    display: block;
    padding: 10px 15px 10px 38px;
    text-decoration: none;
    /*color: #999;*/
    color: #fff;    
}

.side-nav>li>ul>li>a:hover {
    color: #fff;
}

.navbar .nav > li > a > .label {
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  position: absolute;
  top: 14px;
  right: 6px;
  font-size: 10px;
  font-weight: normal;
  min-width: 15px;
  min-height: 15px;
  line-height: 1.0em;
  text-align: center;
  padding: 2px;
}

.navbar .nav > li > a:hover > .label {
  top: 10px;
}

.navbar-brand {
    padding: 5px 15px;
}

/* form controls */
input[type=text],input[type=password],select,input[type=email],input[type=date]
{
	width:100%;
	height:40px;
	padding:5px;
	margin:8px 0;
	display:inline-block;
	border:1px solid #ccc;
	box-sizing:border-box;

	border-radius: 8px;
  background-color: #f1f1f1;
}

button{
background-color:#4CAF50;
color:white;
padding:14px 20px;
margin:8px 0;
border:none;
cursor:pointer;
width:100px;
border-radius: 8px;
float: right;
margin:5px;

}
#btn
{
	/*background-color:#09ebd4;*/
	background-color:blue;
	border:2px solid white;
	padding:5px;
	color:white;
	cursor:pointer;
	border-radius: 5px;
}
#button_clear{
background-color:#f44336;
color:white;
padding:12px 15px;
margin:8px 0;
border:2px solid white;
cursor:pointer;
width:100px;
border-radius: 8px;
float: right;
margin:5px;

}
#button_ok{
width:100px;
background-color:#4CAF50;
color:white;
padding:12px 15px;
margin:8px 0;
border:2px solid white;
cursor:pointer;
border-radius: 8px;
float: right;
margin:5px;
}
label
{
width:100%;
font-family:"Comic Sans MS", cursive, sans-serif;
font-size:15px;
font-weight:bold;
font-variant:small-caps;
color:black;
}

button:hover
{
opacity:0.8;
}
.cancelbtn
{
width:100px;
padding:10px 18px;
background-color:#f44336;
border-radius: 8px;
float: right;
margin:5px;
}
.imgcontainer
{
text-align:center;
margin:24px 0 12px 0;
position:relative;
}
img.user
{
width:20%;
border-radious:20%;
}
.container
{
padding:16px;
width:100%;
}
span.psw
{
float:right;
padding-top:16px;
}

.modal
{
display:none;
position:absolute;
z-index:1;
left:0;
top:0;
width:100%;
height:100%;
overflow:auto;
background-color:rgb(0,0,0);
background-color:rgba(0,0,0,0.4);
padding-top:60px;
}
.modal-content{
background-color:#fefefe;
margin:1% auto 15% auto;
border:3px solid #888;
width:40%;
}
.close
{
position:absolute;
right:25px;
top:0;
color:#000;
font-size:35px;
font-weight:bold;
}
.close:hover, .close:focus
{
color:red;
cursor:pointer;
}
.animate
{
-webkit-animation:animatezoom 0.6s;
animation:animatezoom 0.6s;
}
@-webkit-keyframes animatezoom{
from
{
-webkit-transform:scale(0)
}
to{
-webkit-transform:scale(1)
}
}
@keyframes animatezoom{
from{
transform:scale(0)}
to{transform:scale(1)}
}
@media screen and(max-width:300px)
{
span.psw
{
display:black;
float:none;
}
.cancelbtn
{
width:100%;
}
}

/*Flip an image for logo */

.flip-box {
  background-color: transparent;
  width: 100%px;
  height: 90px;
  border: 1px solid #f1f1f1;
  perspective: 1000px;
}

.flip-box-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.8s;
  transform-style: preserve-3d;
}

.flip-box:hover .flip-box-inner {
  transform: rotateY(180deg);
}

.flip-box-front, .flip-box-back {
  position: absolute;
  width: 100%;
  height: 100%;
  backface-visibility: hidden;
}

.flip-box-front {
  background-color: #bbb;
  color: black;
}

.flip-box-back {
  background-color: #555;
  color: white;
  transform: rotateY(180deg);
}



/* Text Animation */

#text-animate{
  position: relative;
  font-family: copperplate;
  text-transform: uppercase;
  font-size: 20px;
  font-weight:bold;
  letter-spacing: 4px;
  overflow: hidden;
  background: linear-gradient(90deg, #f0f, #00f, #f0f);
  background-repeat: no-repeat;
  background-size: 100%;
  /*animation: animate 3s linear infinite;*/
  -webkit-background-clip: text;
  -webkit-text-fill-color: rgba(255, 255, 255, 0);
  text-align:center;
}

@keyframes animate{
  0% {
    background-position: -500%;
  }
  100% {
    background-position: 500%;
  }
}

</style>

</head>
<body>
<div id="header">
	<div class="w3-container w3-teal">
		<nav class="navbar navbar-inverse" style="background-color:red;border:none;">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-1">
						<img src="images/image.webp" alt="market" class="img-responsive img-circle" style="margin-top:8px;">
					</div>
					<div class="col-lg-6">
						<p id="font_head">Automatic super market</p>
					</div>
					<div class="col-lg-5">

						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
								<span class="icon-bar"></span>
								<span class="icon-bar "></span>
								<span class="icon-bar"></span>                        
							</button>
							<a class="navbar-brand" href="#"></a>
						</div>
						<div class="collapse navbar-collapse" id="myNavbar" style="float:right;">	  
							<ul class="nav navbar-nav" style="padding:20px;color:white;">
								<li style="padding-left:5px;"><a href="home.html" id="font_menu"><span class="glyphicon glyphicon-user"></span>&nbsp admin pannel</a></li>	
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
	</div>	
</div>


<!-- Body content-->
<div id="content_body">	

     <!-- Dashboard -->	
	<div id="throbber" style="display:none; min-height:120px;"></div>
		<div id="noty-holder"></div>
			<div id="wrapper">
				<div class="collapse navbar-collapse navbar-ex1-collapse" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="http://cijulenlinea.ucr.ac.cr/dev-users/"></a>
					</div>
					<ul class="nav navbar-nav side-nav">
						<li style="background-color: skyblue;">""")
print("""                   <a href="#" data-toggle="collapse" data-target="#submenu-1" id="font_dash"><i class="fa fa-fw fa-search"></i>Supermarket<i class="fa fa-fw fa-angle-down pull-right"></i><span style="padding-left:100px;"></span></a>
							<ul id="submenu-1" class="collapse">
								<li><a href="newrequest_shops.py?id=%s" id="font_dashmenu"><i class="fa fa-angle-double-right"></i>new request</a></li>
								<li><a href="admin_viewshops.py?id=%s" id="font_dashmenu"><i class="fa fa-angle-double-right"></i>existing</a></li>
							</ul>
						</li>
						<li style="background-color: skyblue;">
							<a href="admin_viewcustomer.py?id=%s" data-toggle="collapse" data-target="#submenu-2" id="font_dash"><i class="fa fa-fw fa-star"></i>Customer<i class="fa fa-fw fa-angle-down pull-right"></i><span style="padding-left:138px;"></span></a>                    
						</li>
						<li style="background-color: skyblue;">
							<a href="admin_reply.py?id=%s" data-toggle="collapse" data-target="#submenu-3" id="font_dash"><i class="fa fa-fw fa-star"></i>Feedback<i class="fa fa-fw fa-angle-down pull-right"></i><span style="padding-left:160px;"></span></a>
						</li>
						<li style="background-color: skyblue;">
							<a href="home.py?id=%s" data-toggle="collapse" data-target="#submenu-3" id="font_dash"><i class="fa fa-fw fa-star"></i>logout<i class="fa fa-fw fa-angle-down pull-right"></i><span style="padding-left:160px;"></span></a>
						</li>
					</ul>
				</div>	
			</div>
		</div>

	<!-- Page content -->
		<div style="margin-left:260px;margin-top:100px;">
			<div id="page-wrapper">
				<div class="container-fluid">
					<div class="row" id="main">
						<div class="col-sm-12 col-md-12 well">"""%(pid,pid,pid,pid,pid))

sql="""select * from feedback"""
cur.execute(sql)
r=cur.fetchall()


for i in r:

  print("""
      <table>
      <tr><th>feedid</th><td>%s</td></tr><br>
      <tr><th>ratings</th><td>%s</td></tr>
      <tr><th>feedbacks</th><td>%s</td></tr>
      <tr><th>sendid</th><td>%s</td></tr>
      <tr><th>reply</th><td>%s</td></tr>
      <td><a href="feedback_edit.py?id=%s">Reply...</a></td>
      """ %(i[1],i[2],i[3],i[4],i[5],i[0]))
print("</table>")
conn.close()

print("""			</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>
</body>
</html>

""")