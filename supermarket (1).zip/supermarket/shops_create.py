#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")
print("""
 <html>
  <head> 
     <title>create password shops</title>
	 <style>


.navigation-bar {
    width: 100%;
	height: 70px;
    position: fixed;	
    background-color: red; 
	margin-top: -200px;
	margin-left: -7px;
}
.logo {
    display: inline-block;
    vertical-align: top;
    width: 80px;
    height: 60px;
    margin-right: 20px;
    margin-top: 10px;
    border-radius: 60px;	
}
.auto
    {
	width:677px;
	height:60px;
	margin:0px;
	text-align:top;
	text-bottom:15pt;
	font-size:20pt;
	color:white;
	margin-left: 80px;
	margin-top:-40px;
	}
.h-me
    {
	height:60px;
	width:677px;
	margin:0px;
	margin-left:1250px;
	text-align:top;
	text-bottom: 15pt;
	font-size: 17pt;
	margin-top: -60px;
	color:white;
	outline: none;
}

.home
   {
    height:20px;
    width: 25px;
	margin-top:-60px;
	margin-left:1215px;	
}

 
	 </style>
	</head>
<body style="background-color: gray;">
  <nav class="navigation-bar">
    <img class="logo" src="images/image.webp">
	<h3 class="auto">Automatic supermarket</h3>
	<img src="images/home.jpg" class="home"><a href="home.py" style="text-decoration:none"><h3 class="h-me">home</h3></a>
	</nav>

<center style="margin-top:200px;">	   
<table border="0" cellpadding="3" cellspacing="0">
  <form action="#" method="post">
    <h2 style="margin-bottom: 50px; color: blue;">Create your new password....</h2>
    <tr>
        <td style="font-size:20px; color:red;">
           Create Password:
        </td>
        <td>
            <input type="password" id="txtPassword" />
        </td>
    </tr>
    <tr>
        <td style="font-size:20px; color:red;">
            Confirm Password:
        </td>
        <td>
            <input type="password" id="txtConfirmPassword" />
        </td>
    </tr>
    <tr>
        <td>
        </td>
        <td>
            <a href="shops_login.py"><input type="button" id="btnSubmit" value="Submit"  style="margin-left: 100px; color:red;"onclick="return Validate()" /></a>
        </td>
    </tr>
	</form>
</table>
</center>
</body>
<script type="text/javascript">
    function Validate() {
        var password = document.getElementById("txtPassword").value;
        var confirmPassword = document.getElementById("txtConfirmPassword").value;
		if(password=='')
	     {
		 alert("please enter password");
		 }
		 else if(password.length < 6 || password.length > 6)
		{
			alert("Password min and max length is 6.");
		}
        else if (password != confirmPassword) {
            alert("Passwords do not match.");
        }
    }
</script>
   </html>
 
""")