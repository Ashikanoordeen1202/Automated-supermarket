#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

print("""
    <html>
<head>
    <title>home page</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid" class="jumbotron text-center">
		<div class="row" style="background-color: red; color:white; font-size:17px;">
		     <div class="col-sm-1"><img class="img-circle" height="50" width="100%" src="images/image.webp"></div>
			 <div class="col-sm-6"><h3 width="100%" ><b>Automatic supermarket</b></h3></div>
		 </div>
		 
		 
	 <div class="row" style="background-size:cover;background-color:gray;">
		 <a href="#"><div class="col-sm-3"><h4 class="glyphicon glyphicon-home" style="color:white; font-size:19px;">&nbsp;Home</h4></div></a>
		 <a href="customer_offers_view.py"><div class="col-sm-3"><h4 class="glyphicon glyphicon-lock" style="color:white; font-size:19px;">&nbsp;offers</h4></div></a>
		 <div class="col-sm-3">
		  <div class="cart">
			<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">REGISTER
			<span class="caret"></span></button>
			<ul class="dropdown-menu">
				<li><a href="customer_register.py">Customer</a></li>
				<li><a href="shops_register.py">Shops_owner</a></li>
				</ul>
		</div>
    </div>		
		        
		 
		 <div class="col-sm-3">
		 <div class="cart">
			<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">LOGIN
			<span class="caret"></span></button>
			<ul class="dropdown-menu">
				<li><a href="admin_login.py">Admin</a></li>
				<li><a href="customer_login.py">Customer</a></li>
				<li><a href="shops_login.py">Shops_owner</a></li>
				</ul>
		</div>
    </div>
	</div>
	
	
    <div class="row">
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
	<div class="carousel-inner">
		<div class="item active">
			<img src="images\market1.jpeg" alt="Los Angeles" style="width:100%;height:60%;" class="img-rounded">
        </div>

      <div class="item">
        <img src="images\market2.jpeg" alt="Chicago" style="width:100%;height:60%;" class="img-rounded">
      </div>
    
      <div class="item">
        <img src="images\market3.jpg" alt="New york" style="width:100%;height:60%;" class="img-rounded">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
</div>
    
	 
	 
	 <div class="row" style="background-size:cover;background-color:green;">
	    <div class="col-sm-4"><a href="#"><h3 style="color:white;"><b>shree pazhamudir supermarket</b></h3></a>
             <marquee>
            <img src="images/image.webp" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/market3.jpg" width="200px" height="80px">
			  <img src="images/fruits.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/fruits6.jpg" width="200px" height="80px">
			 <img src="images/veg1.jpg" width="200px" height="80px">
			 <img src="images/cosmetics2.jpg" width="200px" height="80px">
		 </marquee>
     </div>
	     <div class="col-sm-4"><a href="#"><h3 style="color:white;"><b>Ram supermarket</b></h3></a>
             <marquee>
			 <img src="images/logo (1).png" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/market2.jpeg" width="200px" height="80px">
			  <img src="images/veg1.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/snacks.jpg" width="200px" height="80px">
			 <img src="images/fruits5.jpg" width="200px" height="80px">
			 <img src="images/cosmetics.jpg" width="200px" height="80px">
            
		 </marquee>
     </div>
	   <div class="col-sm-4"><a href="#"><h3 style="color:white;"><b>Hyper supermarket</b></h3></a>
             <marquee>
            <img src="images/logo2.png" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/market1.jpeg" width="200px" height="80px">
			  <img src="images/shampoo.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/fruits7.jpg" width="200px" height="80px">
			 <img src="images/veg2.jpg" width="200px" height="80px">
			 <img src="images/cosmatics3.jpg" width="200px" height="80px">
		 </marquee>
     </div>
	</div> 
	 
	
	 
	 <div class="row" style="background-size:cover;background-color:green;">
	    <div class="col-sm-4"><a href="#"><h3 style="color:white;"><b>shree supermarket</b></h3></a>
             <marquee>
                <img src="images/logo (1).png" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
                <img src="images/market2.jpeg" width="200px" height="80px">
			    <img src="images/veg1.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
                <img src="images/snacks.jpg" width="200px" height="80px">
			    <img src="images/fruits5.jpg" width="200px" height="80px">
			    <img src="images/cosmetics.jpg" width="200px" height="80px">
		 </marquee>
     </div>
	     <div class="col-sm-4"><a href="#"><h3  style="color:white;"><b>Sri supermarket</b></h3></a>
             <marquee>
			    <img src="images/logo2.png" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/market1.jpeg" width="200px" height="80px">
			  <img src="images/shampoo.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/fruits7.jpg" width="200px" height="80px">
			 <img src="images/veg2.jpg" width="200px" height="80px">
			 <img src="images/cosmatics3.jpg" width="200px" height="80px">
		 </marquee>
     </div>
	   <div class="col-sm-4"><a href="#"><h3 style="color:white;"><b>koki supermarket</b></h3></a>
             <marquee>
            <img src="images/image.webp" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/market3.jpg" width="200px" height="80px">
			  <img src="images/fruits.jpg" width="200px" height="80px" >&nbsp;&nbsp;&nbsp;&nbsp;
             <img src="images/fruits6.jpg" width="200px" height="80px">
			 <img src="images/veg1.jpg" width="200px" height="80px">
			 <img src="images/cosmetics2.jpg" width="200px" height="80px">
		 </marquee>
     </div>
	 
   </div>
 </body>
</html>

""")