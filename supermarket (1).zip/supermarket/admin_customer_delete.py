#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

import cgi
import pymysql

conn=pymysql.connect("localhost","root","","supermarket")
cur=conn.cursor()

f=cgi.FieldStorage()
pid=f.getvalue('id')
q1="""select * from customer_details where id=%s""" %(pid)
cur.execute(q1)
r=cur.fetchone()


if r!=None:
    q2= """delete from customer_details where id=%s""" %(pid)
    cur.execute(q2)
    conn.commit()
    print("""<script>alert("data deleted sucessfully");</script>""")

else:
    print("""<script>alert("record not found");</script>""")


q3="""select * from customer_details"""
try:
    cur.execute(q3)
    res=cur.fetchall()
except:
    print("<p>not inserted</p>")
conn.close()
