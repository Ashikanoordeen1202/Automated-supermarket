#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

import cgi
import pymysql

print("""
  <!DOCTYPE html>
  <html>
  <head>
  <title>Forgot_shops</title>
  <style>
   body
   {
     margin:0px;
	 background-color:#27a465;
	 color:#f7f7f7; 
	 font-family:Arial, Helvetica, sans-serif;
   }
   
   .navigation-bar {
    width: 100%; 
    height: 70px; 
    background-color: red; 
}
.logo {
    display: inline-block;
    vertical-align: top;
    width: 80px;
    height: 60px;
    margin-right: 20px;
    margin-top: 10px;
    border-radius: 60px;	
}
.auto
    {
	width:677px;
	height:60px;
	margin:0px;
	text-align:top;
	text-bottom:15pt;
	font-size:20pt;
	color:white;
	position:fixed;
	margin-left: 80px;
	margin-top:-40px;
	}
.h-me
    {
	height:60px;
	width:677px;
	margin:0px;
	margin-left:1300px;
	text-align:top;
	text-bottom: 15pt;
	font-size: 15pt;
	margin-top: -40px;
	color:white;
	outline: none;
}

.home
   {
    height:20px;
    width: 25px;
	margin-top:30px;
	margin-left:1150px;	
} 	  
   
   #main
   {
     width:600px;
	 height:260px; 
	 margin-left:auto; 
	 margin-right:auto; 
	 border-radius:5px; 
	 padding-left:10px; 
	 margin-top:100px;
     border-top:3px double #f1f1f1; 
	 border-bottom:3px double #f1f1f1; 
	 padding-top:20px;
   }
   #main table
   {
     font-family:"Comic Sans MS", cursive;
   } 
  #main .tb
  {
    height:28px; 
	width:230px; 
	border:1px solid #27a465; 
	color:#27a465; 
	font-weight:bold; 
	border-left:5px solid #f7f7f7; 
	opacity:0.9;
  }

   #main .btn
   {
    width:80px; 
	height:32px; 
	outline:none; 
	font-weight:bold; 
	border:0px solid #27a465; 
	text-shadow: 0px 0.5px 0.5px #fff;	
    border-radius: 2px; 
	font-weight: 600;
    margin-left: 150px;	
	color: #27a465; 
	letter-spacing: 1px; 
	font-size:14px;	
	-webkit-transition: 1s; 
	-moz-transition: 1s; 
	transition: 1s;
   }
  
   #main .btn:hover
   {
    background-color:#27a465; 
	outline:none;  
	border-radius: 2px; 
	color:#f1f1f1; 
	border:1px solid #f1f1f1;
   }
   
  </style>
  <script>
   function login()
	{
		var uname = document.getElementById("email").value;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(uname=='')
		{
			alert("please enter user name.");
		}
		else if(!filter.test(uname))
		{
			alert("Enter valid email id.");
		}
		else
		{
	alert('success');
  
			}
	}		
	
  </script>
 </head>
<body>
  <nav class="navigation-bar">
    <img class="logo" src="images/image.webp">
	<h3 class="auto">Automatic supermarket</h3>
	<img src="images/home.jpg" class="home"><a href="home.py" style="text-decoration:none"><h6 class="h-me">home</h6></a>
	</nav>
	<div id="main">
	<div class="h-tag">
	<h2 style="color:blue;">Retrive password....</h2>
	</div>
	<div class="login">
	<table cellspacing="2" align="center" cellpadding="8" border="0">
	<form action="#" method="post">
	<tr>
	<td>Shops id</td>
	<td><input type="text" name="shopsid" class="tb" ></td>
	</tr>
	<tr>
	<td></td>
	<td>
	<input type="submit" value="send" name="sub"><input type="reset" value="cancel" name="can">
	</tr>
	</form>
	</table>
	</div>
	</div>
  </body>
  </html>

""")

f=cgi.FieldStorage()
pshops=f.getvalue('shopsid')
psub=f.getvalue('sub')
if psub!=None:

        conn = pymysql.connect("localhost","root","","supermarket")
        cur = conn.cursor()
        q = """select username,password from shops_regdetails where shops_id='%s'""" %(pshops)
        cur.execute(q)
        r=cur.fetchone()
        if r[0]!=None:

            import smtplib
            fromaddr='supermarket2105@gmail.com'
            password ='2105market'
            toaddrs=r[1]
            msg="""
                Hi Welcome your,
                Password: %s
                """ %(r[0])

            try:
                server=smtplib.SMTP('smtp.gmail.com:587')
                server.ehlo()
                server.starttls()
                server.login(fromaddr, password)
                server.sendmail(fromaddr,toaddrs,msg)
                server.quit()
                cur.execute(q)
                conn.commit()
                print("""<script>alert("Mail sent!!");</script>""")
            except:
                print("""<script>alert("Mail not sent!!");</script>""")
            conn.close()

        else:
            print("""alert("Username does not exist")""")