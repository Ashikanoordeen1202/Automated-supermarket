#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

print("""
    <html>
<head>
    <title>home page</title>
</head>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<body style="background-color: skyblue;">
	<div class="container-fluid" class="jumbotron text-center">
		<div class="row" style="background-color: red; color:white; font-size:17px;">
		     <div class="col-sm-1"><img class="img-circle" height="50" width="100%" src="images/image.webp"></div>
			 <div class="col-sm-6"><h3 width="100%" ><b>Automatic supermarket</b></h3></div>
			 <div class="col-sm-3 pull-right"><h3><b><a style="color: white;" href="home.py">Home</a></b></h3></div>
		 </div>
</body>
</html>""")

import cgi,os
import cgitb; cgitb.enable()
import pymysql as ps

form = cgi.FieldStorage()
pid = form.getvalue("id")


conn=ps.connect("localhost","root","","supermarket")
cur=conn.cursor()

sql="""select * from offers"""
cur.execute(sql)
r=cur.fetchall()


for i in r:

  print("""
      <table>
      <tr><td colspan="2"><img src="%s" height="75" width="75"></td></tr><br>
      <tr><th>shops id</th><td>%s</td></tr><br>
      <tr><th>item no</th><td>%s</td></tr>
      <tr><th>product name</th><td>%s</td></tr>
      <tr><th>price</th><td>%s</td></tr>
      <tr><th>quantity</th><td>%s</td></tr>
      <tr><th>discount</th><td>%s</td></tr>
      <tr><th>description</th><td>%s</td></tr>
      """ % ( "file/"+i[3],i[1],i[2],i[4],i[5],i[6],i[7],i[8]))
print("</table>")
conn.close()
