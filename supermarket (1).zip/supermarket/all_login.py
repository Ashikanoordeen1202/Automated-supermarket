#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")
print("""

<html>
<head>
    <title>all login</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<style>
	 body
   {
   background: url(images/papaya.jpg) no-repeat center center fixed ; 
  background-size: cover;	
  }
  .navigation-bar {
    width: 100%; 
    height: 70px;	
    background-color: red; 
}
.logo {
    display: inline-block;
    vertical-align: top;
    width: 80px;
    height: 60px;
    margin-right: 20px;
    margin-top: 10px;
    border-radius: 60px;	
}
.auto
    {
	width:677px;
	height:60px;
	margin:0px;
	text-align:top;
	text-bottom:15pt;
	font-size:20pt;
	color:blue;
	margin-left: 80px;
	margin-top:-40px;
	}
.h-me
    {
	height:60px;
	width:677px;
	margin:0px;
	margin-left:1250px;
	text-align:top;
	text-bottom: 15pt;
	font-size: 15pt;
	margin-top: -60px;
	color:blue;
	outline: none;
}

.home
   {
    height:20px;
    width: 25px;
	margin-top:-60px;
	margin-left:1215px;	
}
.pls
   {
     margin-top: 80px;
	 align:center;
	 color: black;
	 margin-left: 450px;
	 
	 
	 }
</style>
</head>
<body>
     <nav class="navigation-bar">
    <img class="logo" src="images/image.webp">
	<h4 class="auto" style="color:white;">Automatic supermarket</h4>
	<img src="images/home.jpg" class="home"><a href="home.html" style="text-decoration:none;"><h6 class="h-me" style="color:white;">home</h6></a>
	</nav>
	<h1 class="pls">Please Login Here......</h1>
	  <div class="row" style="margin-top: 80px;">
		  <div class="list-group">
		      <div class="col-sm-4"></div>
		      <div class="col-sm-4">
		        <h3><a href="admin_login.py" class="list-group-item list-group-item-primary" target="_blank"> <span class="glyphicon glyphicon-edit">ADMIN</span></a></h3>
		        <h3><a href="shops_login.py" class="list-group-item list-group-item-warning" target="_blank"><span class="glyphicon glyphicon-edit">SHOPS OWNER</span></a></h3>
		        <h3><a href="customer_login.py" class="list-group-item list-group-item-default" target="_blank"><span class="glyphicon glyphicon-edit">CUSTOMER</span></a></h3>
               </div>
			   <div class="col-sm-4"></div>
		   </div>
        </div>
</body>
</html>



""")