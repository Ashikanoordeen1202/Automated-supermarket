#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")
print("""

<!DOCTYPE html>
  <html>
  <head>
  <title>Login Form In Admin</title>
  <style>
   body
   {
     margin:0px;
	 background-color:#27a465;
	 color:#f7f7f7; 
	 font-family:Arial, Helvetica, sans-serif;	
   }
   
   .navigation-bar {
    width: 100%; 
    height: 70px; 
    background-color: red; 
}
.logo {
    display: inline-block;
    vertical-align: top;
    width: 80px;
    height: 60px;
    margin-right: 20px;
    margin-top: 10px;
    border-radius: 60px;	
}
.auto
    {
	width:677px;
	height:60px;
	margin:0px;
	text-align:top;
	text-bottom:15pt;
	font-size:20pt;
	color:white;
	position:fixed;
	margin-left: 80px;
	margin-top:-40px;
	}
.h-me
    {
	height:60px;
	width:677px;
	margin:0px;
	margin-left:1300px;
	text-align:top;
	text-bottom: 15pt;
	font-size: 15pt;
	margin-top: -40px;
	color:white;
	outline: none;
}
.reg
{
   height: 60px;
   width: 677px;
   margin: 0px;
   margin-left: 1000px;
   text-align: top;
   text-bottom: 15pt;
   font-size: 15pt;
   margin-top:-60px;
   color: white;
   outline: none;
   }

.home
   {
    height:20px;
    width: 25px;
	margin-top:30px;
	margin-left:1150px;	
}
   
      	  
   
   #main
   {
     width:600px;
	 height:260px; 
	 margin-left:auto; 
	 margin-right:auto; 
	 border-radius:5px; 
	 padding-left:10px; 
	 margin-top:100px;
     border-top:3px double #f1f1f1; 
	 border-bottom:3px double #f1f1f1; 
	 padding-top:20px;
   }
   #main table
   {
     font-family:"Comic Sans MS", cursive;
   } 
  #main .tb
  {
    height:28px; 
	width:230px; 
	border:1px solid #27a465; 
	color:#27a465; 
	font-weight:bold; 
	border-left:5px solid #f7f7f7; 
	opacity:0.9;
  }

   #main .btn
   {
    width:80px; 
	height:32px; 
	outline:none; 
	font-weight:bold; 
	border:0px solid #27a465; 
	text-shadow: 0px 0.5px 0.5px #fff;	
    border-radius: 2px; 
	font-weight: 600; 
	color: #27a465; 
	letter-spacing: 1px; 
	font-size:14px;	
	-webkit-transition: 1s; 
	-moz-transition: 1s; 
	transition: 1s;
   }
  
   #main .btn:hover
   {
    background-color:#27a465; 
	outline:none;  
	border-radius: 2px; 
	color:#f1f1f1; 
	border:1px solid #f1f1f1;
   }
	   
   
  </style>
  <script>
   function login()
	{
		var uname = document.getElementById("email").value;
		var pwd = document.getElementById("pwd1").value;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(uname =='')
		{
			alert("please enter user name.");
		}
		else if(pwd=='')
		{
        	alert("enter the password");
		}
		else if(!filter.test(uname))
		{
			alert("Enter valid email id.");
		}
		else if(pwd.length < 6 || pwd.length > 6)
		{
			alert("Password min and max length is 6.");
		}
		else
		{
	alert('Thank You for Login');
  
			}
	}		
	
  </script>
 </head>
<body>
  <nav class="navigation-bar">
    <img class="logo" src="images/image.webp">
	<h3 class="auto">Automatic supermarket</h3>
	<a href="home.py" style="text-decoration:none"><h6 class="h-me">home</h6></a>
	</nav>
	<div id="main">
	<div class="h-tag">
	<h2>Welcome To Customer My Account Login</h2>
	</div>
	<div class="login">
	<table cellspacing="2" align="center" cellpadding="8" border="0">
	<form action="#" method="post">
	<tr>
	<td>Enter User Name :</td>
	<td><input type="text" placeholder="Enter user name here" id="email" class="tb" name="uname"></td>
	</tr>
	<tr>
	<td>Enter Password :</td>
	<td><input type="password" placeholder="Enter Password here" id="pwd1" class="tb" name="pwd" /></td>
	</tr>
	<tr>
	<td></td>
	<td>
	<input type="submit" name="sub" onClick="submit()" value="Submit">
         <input type="button" onClick="location.href='home.py'" value="Cancel"></td></tr>
	<tr>
	<td><h4 style="font-size:20px; margin-top:0px;"><a href="customer_forgot.py" style="text-decoration:none; color:red;">forgot password?</a></h4></td>
	<td><h5 style="font-size: 20px; margin-top: 0px;"><i style="text-decoration: none; color:blue; margin-left:120px;">newuser<a href="register.html" style="text-decoration:none; color:red;" > register here?</a></i></h5></td></tr>
	</form>
	</table>
	</div>
	</div>
    
  </body>
  </html>

""")

import pymysql, cgi
f = cgi.FieldStorage()
puname = f.getvalue("uname")
ppwd = f.getvalue("pwd")
psub = f.getvalue("sub")

if psub != None:
    conn = pymysql.connect("localhost", "root", "", "supermarket")
    cur = conn.cursor()

    q = """select id from customer_details where username='%s' and password='%s'""" %(puname, ppwd)
    cur.execute(q)
    rec = cur.fetchone()
    # print(rec)

    if rec != None:
        print("""
		<script>
			location.href="customer_pannel.py?id=%s";
		</script>""" % (rec[0]))
    else:
        print("""<script>
		alert("Invalid username or password..");
		</script>""")