#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")


print("welcome")

import cgi, pymysql,cgitb;cgitb.enable()

f = cgi.FieldStorage()
pid = f.getvalue("id")

conn =pymysql.connect("localhost","root","","supermarket")
cur =conn.cursor()

q ="""select * from shops_regdetails where id=%s""" %(pid)
cur.execute(q)
rec =cur.fetchone()
print("""<pre>
    email: %s
    </pre>""" % (rec[3]))
