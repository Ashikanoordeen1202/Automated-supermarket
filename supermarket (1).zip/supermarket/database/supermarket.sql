-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2020 at 04:30 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supermarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`) VALUES
(1, 'admin', '54321');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `id` int(20) NOT NULL,
  `customer_id` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `phone` bigint(30) NOT NULL,
  `profile` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`id`, `customer_id`, `name`, `email`, `username`, `password`, `phone`, `profile`) VALUES
(3, 'custid0003', 'kokila', 'koki@gmail.com', 'koki@gmail.com', '123456', 8923450178, 'None'),
(7, 'custid0007', 'koki', 'koki@gmail.com', 'koki@gmail.com', 'kokila', 8923450178, 'None');

-- --------------------------------------------------------

--
-- Table structure for table `customer_purchase_list`
--

CREATE TABLE `customer_purchase_list` (
  `id` int(50) NOT NULL,
  `customer_id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` varchar(50) NOT NULL,
  `quantity` varchar(60) NOT NULL,
  `total_amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_purchase_list`
--

INSERT INTO `customer_purchase_list` (`id`, `customer_id`, `email`, `product_name`, `price`, `quantity`, `total_amount`) VALUES
(1, '0001', 'baby powder', 'koki@gmail.com', 'Rs.50', '5', '');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(30) NOT NULL,
  `feed_id` varchar(30) NOT NULL,
  `ratings` int(50) NOT NULL,
  `feedbacks` varchar(40) NOT NULL,
  `send_id` varchar(40) NOT NULL,
  `reply` varchar(30) NOT NULL,
  `ans` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `feed_id`, `ratings`, `feedbacks`, `send_id`, `reply`, `ans`) VALUES
(1, 'feed1', 0, 'vds ', 'shopid0001', 'csjb NC SK', ''),
(2, 'feed2', 0, 'dvsb', 'custid0007', '', ''),
(3, 'feed3', 0, 'css', 'custid0007', '', ''),
(4, 'feed4', 0, 'good', 'shopid0028', '', ''),
(5, 'feed5', 0, 'None', 'shopid0028', '', ''),
(6, 'feed6', 0, 'None', 'shopid0028', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(50) NOT NULL,
  `shop_id` varchar(50) NOT NULL,
  `item_no` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `discount` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `shop_id`, `item_no`, `image`, `product_name`, `price`, `quantity`, `discount`, `description`) VALUES
(1, 'shopid0028', 'item1', 'aloe vera.jpeg', 'baby powder', 'Rs.50', '5', '50', 'feeq ');

-- --------------------------------------------------------

--
-- Table structure for table `products_add`
--

CREATE TABLE `products_add` (
  `id` int(100) NOT NULL,
  `shop_id` varchar(150) NOT NULL,
  `item_no` varchar(150) NOT NULL,
  `image` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_add`
--

INSERT INTO `products_add` (`id`, `shop_id`, `item_no`, `image`, `product_name`, `price`, `quantity`, `description`) VALUES
(5, 'shopid0028', 'item5', 'baby powder.jpg', 'baby powder', 'Rs.50', '1', 'baby use'),
(6, 'shopid0028', 'item6', 'baby oil.jpg', 'oil', 'RS.60', '5', 'baby use'),
(7, 'shopid0028', 'item7', 'carrot1.jpg', 'carrot', 'Rs.50', '5kg', 'cooking');

-- --------------------------------------------------------

--
-- Table structure for table `shops_acceptdetails`
--

CREATE TABLE `shops_acceptdetails` (
  `id` int(30) NOT NULL,
  `shops_id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `products` varchar(50) NOT NULL,
  `phone` bigint(50) NOT NULL,
  `request` varchar(50) NOT NULL,
  `profile` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `accept` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shops_regdetails`
--

CREATE TABLE `shops_regdetails` (
  `id` int(30) NOT NULL,
  `shops_id` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `brand_name` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `products` varchar(30) NOT NULL,
  `phone` bigint(30) NOT NULL,
  `request` varchar(30) NOT NULL,
  `profile` varchar(70) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `accept` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shops_regdetails`
--

INSERT INTO `shops_regdetails` (`id`, `shops_id`, `name`, `email`, `brand_name`, `location`, `city`, `products`, `phone`, `request`, `profile`, `username`, `password`, `accept`) VALUES
(28, 'shopid0028', 'kokila', 'koki@gmail.com', 'koki super market', 'aarapalaiyam', 'Madurai', 'grocery', 8923450178, 'my shop add in your website', 'None', 'kokila', 'koki', 'accepted'),
(30, 'shopid0030', 'abi', 'kok@gmail.com', 'palamuthir supermarket', 'aarapalaiyam', 'Madurai', 'grocery', 9523456701, 'my shop add in your applicatio', 'aloe vera.jpeg', '', '', 'new'),
(31, 'shopid0030', 'abi', 'k2105@gmail.com', 'palamuthir supermarket', 'aarapalaiyam', 'Madurai', 'grocery', 9523456701, 'my shop add in your applicatio', 'aloe vera.jpeg', '', '', 'new'),
(32, 'shopid0030', 'abi', 'ka2105@gmail.com', 'palamuthir supermarket', 'aarapalaiyam', 'Madurai', 'grocery', 9523456701, 'my shop add in your applicatio', 'aloe vera.jpeg', '', '', 'new');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_details`
--
ALTER TABLE `customer_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_purchase_list`
--
ALTER TABLE `customer_purchase_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_add`
--
ALTER TABLE `products_add`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shops_acceptdetails`
--
ALTER TABLE `shops_acceptdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shops_regdetails`
--
ALTER TABLE `shops_regdetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_details`
--
ALTER TABLE `customer_details`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer_purchase_list`
--
ALTER TABLE `customer_purchase_list`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products_add`
--
ALTER TABLE `products_add`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shops_acceptdetails`
--
ALTER TABLE `shops_acceptdetails`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shops_regdetails`
--
ALTER TABLE `shops_regdetails`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
